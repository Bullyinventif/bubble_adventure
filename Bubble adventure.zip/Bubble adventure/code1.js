gdjs.BaseCode = {};
gdjs.BaseCode.localVariables = [];
gdjs.BaseCode.idToCallbackMap = new Map();
gdjs.BaseCode.GDNewPanelSpriteObjects1= [];
gdjs.BaseCode.GDNewPanelSpriteObjects2= [];
gdjs.BaseCode.GDGrassObjects1= [];
gdjs.BaseCode.GDGrassObjects2= [];
gdjs.BaseCode.GDBullyObjects1= [];
gdjs.BaseCode.GDBullyObjects2= [];
gdjs.BaseCode.GDGrass_9595groundObjects1= [];
gdjs.BaseCode.GDGrass_9595groundObjects2= [];
gdjs.BaseCode.GDNewSprite2Objects1= [];
gdjs.BaseCode.GDNewSprite2Objects2= [];
gdjs.BaseCode.GDNewSpriteObjects1= [];
gdjs.BaseCode.GDNewSpriteObjects2= [];
gdjs.BaseCode.GDSkullGameOverDialogObjects1= [];
gdjs.BaseCode.GDSkullGameOverDialogObjects2= [];
gdjs.BaseCode.GDBlockObjects1= [];
gdjs.BaseCode.GDBlockObjects2= [];
gdjs.BaseCode.GDGrass_9595ground_9595GObjects1= [];
gdjs.BaseCode.GDGrass_9595ground_9595GObjects2= [];
gdjs.BaseCode.GDJumpObjects1= [];
gdjs.BaseCode.GDJumpObjects2= [];
gdjs.BaseCode.GDTransparentDarkJoystickObjects1= [];
gdjs.BaseCode.GDTransparentDarkJoystickObjects2= [];


gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDBullyObjects1Objects = Hashtable.newFrom({"Bully": gdjs.BaseCode.GDBullyObjects1});
gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.BaseCode.GDNewSpriteObjects1});
gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDBullyObjects1Objects = Hashtable.newFrom({"Bully": gdjs.BaseCode.GDBullyObjects1});
gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.BaseCode.GDNewSpriteObjects1});
gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDJumpObjects1Objects = Hashtable.newFrom({"Jump": gdjs.BaseCode.GDJumpObjects1});
gdjs.BaseCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDBullyObjects1[i].getY() > 1100 ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.BaseCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").SetHealth(0, null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.BaseCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Animation").setAnimationName("Jump");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( !(gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.BaseCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Animation").setAnimationName("Run");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( !(gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( !(gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.BaseCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.BaseCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDBullyObjects1Objects, gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDNewSpriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.BaseCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").Hit(1, true, true, null);
}
}
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").SetPercentDamageReductionOp(100, null);
}
}
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.BaseCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDBullyObjects1Objects, gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDNewSpriteObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.BaseCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").SetPercentDamageReductionOp(0, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").Health(null) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.BaseCode.GDNewSprite2Objects1);
{for(var i = 0, len = gdjs.BaseCode.GDNewSprite2Objects1.length ;i < len;++i) {
    gdjs.BaseCode.GDNewSprite2Objects1[i].getBehavior("Animation").setAnimationName("3");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").Health(null) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.BaseCode.GDNewSprite2Objects1);
{for(var i = 0, len = gdjs.BaseCode.GDNewSprite2Objects1.length ;i < len;++i) {
    gdjs.BaseCode.GDNewSprite2Objects1[i].getBehavior("Animation").setAnimationName("3-2");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").Health(null) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.BaseCode.GDNewSprite2Objects1);
{for(var i = 0, len = gdjs.BaseCode.GDNewSprite2Objects1.length ;i < len;++i) {
    gdjs.BaseCode.GDNewSprite2Objects1[i].getBehavior("Animation").setAnimationName("2-1");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").Health(null) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.BaseCode.GDNewSprite2Objects1);
{for(var i = 0, len = gdjs.BaseCode.GDNewSprite2Objects1.length ;i < len;++i) {
    gdjs.BaseCode.GDNewSprite2Objects1[i].getBehavior("Animation").setAnimationName("1-0");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( !(gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").IsDead(null)) ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SkullGameOverDialog"), gdjs.BaseCode.GDSkullGameOverDialogObjects1);
{for(var i = 0, len = gdjs.BaseCode.GDSkullGameOverDialogObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDSkullGameOverDialogObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDBullyObjects1[i].getBehavior("Health").IsDead(null) ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDBullyObjects1[k] = gdjs.BaseCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.BaseCode.GDBullyObjects1 */
gdjs.copyArray(runtimeScene.getObjects("SkullGameOverDialog"), gdjs.BaseCode.GDSkullGameOverDialogObjects1);
{for(var i = 0, len = gdjs.BaseCode.GDSkullGameOverDialogObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDSkullGameOverDialogObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TransparentDarkJoystick"), gdjs.BaseCode.GDTransparentDarkJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDTransparentDarkJoystickObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDTransparentDarkJoystickObjects1[i].IsDirectionPushed4Way("Left", null) ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDTransparentDarkJoystickObjects1[k] = gdjs.BaseCode.GDTransparentDarkJoystickObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDTransparentDarkJoystickObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TransparentDarkJoystick"), gdjs.BaseCode.GDTransparentDarkJoystickObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDTransparentDarkJoystickObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDTransparentDarkJoystickObjects1[i].IsDirectionPushed4Way("Right", null) ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDTransparentDarkJoystickObjects1[k] = gdjs.BaseCode.GDTransparentDarkJoystickObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDTransparentDarkJoystickObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.BaseCode.GDJumpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BaseCode.mapOfGDgdjs_9546BaseCode_9546GDJumpObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.BaseCode.GDBullyObjects1);
{for(var i = 0, len = gdjs.BaseCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.BaseCode.GDBullyObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SkullGameOverDialog"), gdjs.BaseCode.GDSkullGameOverDialogObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BaseCode.GDSkullGameOverDialogObjects1.length;i<l;++i) {
    if ( gdjs.BaseCode.GDSkullGameOverDialogObjects1[i].IsRestartClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.BaseCode.GDSkullGameOverDialogObjects1[k] = gdjs.BaseCode.GDSkullGameOverDialogObjects1[i];
        ++k;
    }
}
gdjs.BaseCode.GDSkullGameOverDialogObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ecran Titre", false);
}
}

}


};

gdjs.BaseCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BaseCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.BaseCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.BaseCode.GDGrassObjects1.length = 0;
gdjs.BaseCode.GDGrassObjects2.length = 0;
gdjs.BaseCode.GDBullyObjects1.length = 0;
gdjs.BaseCode.GDBullyObjects2.length = 0;
gdjs.BaseCode.GDGrass_9595groundObjects1.length = 0;
gdjs.BaseCode.GDGrass_9595groundObjects2.length = 0;
gdjs.BaseCode.GDNewSprite2Objects1.length = 0;
gdjs.BaseCode.GDNewSprite2Objects2.length = 0;
gdjs.BaseCode.GDNewSpriteObjects1.length = 0;
gdjs.BaseCode.GDNewSpriteObjects2.length = 0;
gdjs.BaseCode.GDSkullGameOverDialogObjects1.length = 0;
gdjs.BaseCode.GDSkullGameOverDialogObjects2.length = 0;
gdjs.BaseCode.GDBlockObjects1.length = 0;
gdjs.BaseCode.GDBlockObjects2.length = 0;
gdjs.BaseCode.GDGrass_9595ground_9595GObjects1.length = 0;
gdjs.BaseCode.GDGrass_9595ground_9595GObjects2.length = 0;
gdjs.BaseCode.GDJumpObjects1.length = 0;
gdjs.BaseCode.GDJumpObjects2.length = 0;
gdjs.BaseCode.GDTransparentDarkJoystickObjects1.length = 0;
gdjs.BaseCode.GDTransparentDarkJoystickObjects2.length = 0;

gdjs.BaseCode.eventsList0(runtimeScene);
gdjs.BaseCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.BaseCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.BaseCode.GDGrassObjects1.length = 0;
gdjs.BaseCode.GDGrassObjects2.length = 0;
gdjs.BaseCode.GDBullyObjects1.length = 0;
gdjs.BaseCode.GDBullyObjects2.length = 0;
gdjs.BaseCode.GDGrass_9595groundObjects1.length = 0;
gdjs.BaseCode.GDGrass_9595groundObjects2.length = 0;
gdjs.BaseCode.GDNewSprite2Objects1.length = 0;
gdjs.BaseCode.GDNewSprite2Objects2.length = 0;
gdjs.BaseCode.GDNewSpriteObjects1.length = 0;
gdjs.BaseCode.GDNewSpriteObjects2.length = 0;
gdjs.BaseCode.GDSkullGameOverDialogObjects1.length = 0;
gdjs.BaseCode.GDSkullGameOverDialogObjects2.length = 0;
gdjs.BaseCode.GDBlockObjects1.length = 0;
gdjs.BaseCode.GDBlockObjects2.length = 0;
gdjs.BaseCode.GDGrass_9595ground_9595GObjects1.length = 0;
gdjs.BaseCode.GDGrass_9595ground_9595GObjects2.length = 0;
gdjs.BaseCode.GDJumpObjects1.length = 0;
gdjs.BaseCode.GDJumpObjects2.length = 0;
gdjs.BaseCode.GDTransparentDarkJoystickObjects1.length = 0;
gdjs.BaseCode.GDTransparentDarkJoystickObjects2.length = 0;


return;

}

gdjs['BaseCode'] = gdjs.BaseCode;
