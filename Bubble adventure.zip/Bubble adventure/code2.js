gdjs.MaisonCode = {};
gdjs.MaisonCode.localVariables = [];
gdjs.MaisonCode.idToCallbackMap = new Map();


gdjs.MaisonCode.eventsList0 = function(runtimeScene) {

};

gdjs.MaisonCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.MaisonCode.eventsList0(runtimeScene);


return;

}

gdjs['MaisonCode'] = gdjs.MaisonCode;
