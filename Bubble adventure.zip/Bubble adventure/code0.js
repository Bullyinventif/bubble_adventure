gdjs.Ecran_32TitreCode = {};
gdjs.Ecran_32TitreCode.localVariables = [];
gdjs.Ecran_32TitreCode.idToCallbackMap = new Map();
gdjs.Ecran_32TitreCode.GDBubble_9595textObjects1= [];
gdjs.Ecran_32TitreCode.GDBubble_9595textObjects2= [];
gdjs.Ecran_32TitreCode.GDAdventure_9595textObjects1= [];
gdjs.Ecran_32TitreCode.GDAdventure_9595textObjects2= [];
gdjs.Ecran_32TitreCode.GDGrassObjects1= [];
gdjs.Ecran_32TitreCode.GDGrassObjects2= [];
gdjs.Ecran_32TitreCode.GDDirtObjects1= [];
gdjs.Ecran_32TitreCode.GDDirtObjects2= [];
gdjs.Ecran_32TitreCode.GDCampfireObjects1= [];
gdjs.Ecran_32TitreCode.GDCampfireObjects2= [];
gdjs.Ecran_32TitreCode.GDBullyObjects1= [];
gdjs.Ecran_32TitreCode.GDBullyObjects2= [];
gdjs.Ecran_32TitreCode.GDTreeObjects1= [];
gdjs.Ecran_32TitreCode.GDTreeObjects2= [];
gdjs.Ecran_32TitreCode.GDTree2Objects1= [];
gdjs.Ecran_32TitreCode.GDTree2Objects2= [];
gdjs.Ecran_32TitreCode.GDTree3Objects1= [];
gdjs.Ecran_32TitreCode.GDTree3Objects2= [];
gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects1= [];
gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects2= [];
gdjs.Ecran_32TitreCode.GDStart_9595button2Objects1= [];
gdjs.Ecran_32TitreCode.GDStart_9595button2Objects2= [];


gdjs.Ecran_32TitreCode.mapOfGDgdjs_9546Ecran_959532TitreCode_9546GDBullyObjects1Objects = Hashtable.newFrom({"Bully": gdjs.Ecran_32TitreCode.GDBullyObjects1});
gdjs.Ecran_32TitreCode.mapOfGDgdjs_9546Ecran_959532TitreCode_9546GDCampfireObjects1Objects = Hashtable.newFrom({"Campfire": gdjs.Ecran_32TitreCode.GDCampfireObjects1});
gdjs.Ecran_32TitreCode.mapOfGDgdjs_9546Ecran_959532TitreCode_9546GDBullyObjects1Objects = Hashtable.newFrom({"Bully": gdjs.Ecran_32TitreCode.GDBullyObjects1});
gdjs.Ecran_32TitreCode.mapOfGDgdjs_9546Ecran_959532TitreCode_9546GDCampfireObjects1Objects = Hashtable.newFrom({"Campfire": gdjs.Ecran_32TitreCode.GDCampfireObjects1});
gdjs.Ecran_32TitreCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.Ecran_32TitreCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Ecran_32TitreCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Ecran_32TitreCode.GDBullyObjects1[k] = gdjs.Ecran_32TitreCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.Ecran_32TitreCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Ecran_32TitreCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.Ecran_32TitreCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("Animation").setAnimationName("Jump");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.Ecran_32TitreCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Ecran_32TitreCode.GDBullyObjects1.length;i<l;++i) {
    if ( !(gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.Ecran_32TitreCode.GDBullyObjects1[k] = gdjs.Ecran_32TitreCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.Ecran_32TitreCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Ecran_32TitreCode.GDBullyObjects1.length;i<l;++i) {
    if ( !(gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Ecran_32TitreCode.GDBullyObjects1[k] = gdjs.Ecran_32TitreCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.Ecran_32TitreCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Ecran_32TitreCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Ecran_32TitreCode.GDBullyObjects1[k] = gdjs.Ecran_32TitreCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.Ecran_32TitreCode.GDBullyObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Ecran_32TitreCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.Ecran_32TitreCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.Ecran_32TitreCode.GDBullyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Ecran_32TitreCode.GDBullyObjects1.length;i<l;++i) {
    if ( !(gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isJumping()) ) {
        isConditionTrue_0 = true;
        gdjs.Ecran_32TitreCode.GDBullyObjects1[k] = gdjs.Ecran_32TitreCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.Ecran_32TitreCode.GDBullyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Ecran_32TitreCode.GDBullyObjects1.length;i<l;++i) {
    if ( gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Ecran_32TitreCode.GDBullyObjects1[k] = gdjs.Ecran_32TitreCode.GDBullyObjects1[i];
        ++k;
    }
}
gdjs.Ecran_32TitreCode.GDBullyObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Ecran_32TitreCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.Ecran_32TitreCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("Animation").setAnimationName("Run");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.Ecran_32TitreCode.GDBullyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Campfire"), gdjs.Ecran_32TitreCode.GDCampfireObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Ecran_32TitreCode.mapOfGDgdjs_9546Ecran_959532TitreCode_9546GDBullyObjects1Objects, gdjs.Ecran_32TitreCode.mapOfGDgdjs_9546Ecran_959532TitreCode_9546GDCampfireObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Ecran_32TitreCode.GDBullyObjects1 */
{for(var i = 0, len = gdjs.Ecran_32TitreCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("Health").Hit(1, true, true, null);
}
}
{for(var i = 0, len = gdjs.Ecran_32TitreCode.GDBullyObjects1.length ;i < len;++i) {
    gdjs.Ecran_32TitreCode.GDBullyObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bully"), gdjs.Ecran_32TitreCode.GDBullyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Campfire"), gdjs.Ecran_32TitreCode.GDCampfireObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Ecran_32TitreCode.mapOfGDgdjs_9546Ecran_959532TitreCode_9546GDBullyObjects1Objects, gdjs.Ecran_32TitreCode.mapOfGDgdjs_9546Ecran_959532TitreCode_9546GDCampfireObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TinyGreenButton"), gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects1.length;i<l;++i) {
    if ( gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects1[k] = gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects1[i];
        ++k;
    }
}
gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Base", false);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Ecran_32TitreCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Ecran_32TitreCode.GDBubble_9595textObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDBubble_9595textObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDAdventure_9595textObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDAdventure_9595textObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDGrassObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDGrassObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDDirtObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDDirtObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDCampfireObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDCampfireObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDBullyObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDBullyObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDTreeObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDTreeObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDTree2Objects1.length = 0;
gdjs.Ecran_32TitreCode.GDTree2Objects2.length = 0;
gdjs.Ecran_32TitreCode.GDTree3Objects1.length = 0;
gdjs.Ecran_32TitreCode.GDTree3Objects2.length = 0;
gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDStart_9595button2Objects1.length = 0;
gdjs.Ecran_32TitreCode.GDStart_9595button2Objects2.length = 0;

gdjs.Ecran_32TitreCode.eventsList0(runtimeScene);
gdjs.Ecran_32TitreCode.GDBubble_9595textObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDBubble_9595textObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDAdventure_9595textObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDAdventure_9595textObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDGrassObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDGrassObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDDirtObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDDirtObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDCampfireObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDCampfireObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDBullyObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDBullyObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDTreeObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDTreeObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDTree2Objects1.length = 0;
gdjs.Ecran_32TitreCode.GDTree2Objects2.length = 0;
gdjs.Ecran_32TitreCode.GDTree3Objects1.length = 0;
gdjs.Ecran_32TitreCode.GDTree3Objects2.length = 0;
gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects1.length = 0;
gdjs.Ecran_32TitreCode.GDTinyGreenButtonObjects2.length = 0;
gdjs.Ecran_32TitreCode.GDStart_9595button2Objects1.length = 0;
gdjs.Ecran_32TitreCode.GDStart_9595button2Objects2.length = 0;


return;

}

gdjs['Ecran_32TitreCode'] = gdjs.Ecran_32TitreCode;
